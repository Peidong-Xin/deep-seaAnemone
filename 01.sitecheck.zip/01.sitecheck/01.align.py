import os
def maft(path):
    shfile = open('01.align.sh','w+')
    for file01 in os.listdir(path):
        path01 = os.path.join(path,file01)
        shfile.write('cd {};java -jar ./MACSE/macse_v2.06.jar -prog alignSequences -seq cds.fa -out_NT ./cds.best.fas -out_AA ./pep.best.fas -gc_def 1;./Gblocks/Gblocks_0.91b/Gblocks ./
    shfile.close()
maft('path/to/aforementioned orthologous genes')
